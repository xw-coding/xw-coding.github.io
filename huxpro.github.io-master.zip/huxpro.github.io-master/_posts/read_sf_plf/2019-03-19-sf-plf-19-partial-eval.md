---
title: "「SF-PLF」19 PE"
subtitle: "Programming Language Foundations - Partial Evaluation"
layout: post
author: "Hux"
header-style: text
hidden: true
tags:
  - SF (软件基础)
  - PLF (编程语言基础)
  - Coq
  - 笔记
---

TBD
