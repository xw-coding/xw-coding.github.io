---
title: "Data Representation - TODO"
subtitle: "「数据表示」待写"
layout: post
author: "Hux"
header-style: text
hidden: true
tags:
  - 笔记
  - 基础
  - C
  - C++
---

- Endianness
- String (Char Sequence e.g. NULL `0x00`)
- Unicode / UTF8
- Struct and Alignment
- Tagging
  - Tagged Pointer
  - NaN tagging
  - Tagged Integer (SMI)